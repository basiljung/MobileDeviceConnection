package com.example.musicsearchapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;


public class SingleSongActivity extends /*AppCompatActivity,*/ YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener {

    TextView titleTextView;
    TextView artistTextView;
    TextView yearTextView;
    TextView countryTextView;
    ImageView coverImageView;

    MusicData musicData = new MusicData();

    String apiKey = "AIzaSyC-9X-vVygufQ3VRSCK4EAa3hxPgAdQFII";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_single_song);

        titleTextView = findViewById(R.id.songTitleView);
        artistTextView = findViewById(R.id.songArtistView);
        coverImageView = findViewById(R.id.songImageView);
        yearTextView = findViewById(R.id.songYearView);
        countryTextView = findViewById(R.id.songCountryView);

        Intent intent = getIntent();

        Log.d("DATA2", intent.getStringExtra("artist"));
        musicData.setArtist(intent.getStringExtra("artist"));
        Log.d("DATA2", intent.getStringExtra("title"));
        musicData.setTitle(intent.getStringExtra("title"));
        Log.d("DATA2", intent.getStringExtra("country"));
        musicData.setCountry(intent.getStringExtra("country"));
        Log.d("DATA2", intent.getStringExtra("coverImage"));
        musicData.setCoverImage(intent.getStringExtra("coverImage"));
        Log.d("DATA2", intent.getStringExtra("masterURL"));
        musicData.setMasterURL(intent.getStringExtra("masterURL"));
        Log.d("DATA2", intent.getStringExtra("year"));
        musicData.setYear(intent.getStringExtra("year"));
        int loop = intent.getIntExtra("loop", 0);
        List<String> genres = new ArrayList<>();
        for (int i = 0; i < loop; i++) {
            genres.add(intent.getStringExtra(String.valueOf(i)));
        }
        musicData.setGenre(genres);

        if(!musicData.getMasterURL().equals("-")) {
            httpRequest(musicData);
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=C1oAZRkOv14")));
            //YouTubePlayerView youTubePlayerView = findViewById(R.id.youtube_player_view);
            //youTubePlayerView.initialize(apiKey, this);
        }

        printData(musicData);


    }

    public void printData(MusicData musicData) {
        artistTextView.append(musicData.getArtist());
        titleTextView.append(musicData.getTitle());
        yearTextView.append(musicData.getYear());
        countryTextView.append(musicData.getCountry());

        Glide
                .with(getApplicationContext())
                .load(musicData.getCoverImage())
                .fitCenter()
                .error(R.drawable.no_photo)
                .into(coverImageView);
    }

    public void httpRequest(final MusicData musicData) {

        String url = musicData.getMasterURL();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        Log.d("strrrrr",">>"+response);

                        try {
                            //getting the whole json object from the response
                            JSONObject obj = new JSONObject(response);

                            JSONArray videos  = obj.getJSONArray("videos");


                            if (videos.length() == 0) {
                                // Not working
                                Toast.makeText(getApplicationContext(), "No videos for the selected URL", Toast.LENGTH_LONG);
                            }

                            //List<String> youtubeVideosList = new ArrayList<>();

                            //for (int i = 0; i < videos.length(); i++) {

                                JSONObject video = videos.getJSONObject(0);



                                if(video.has("uri")) {
                                    musicData.setYooutubeLink(video.getString("uri"));
                                    Log.d("strrr", video.getString("uri"));
                                }
                            //}

                            //musicData.setYooutubeLink(youtubeVideosList);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //displaying the error in toast if occurrs
                        Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });

        //creating a request queue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        //adding the string request to request queue
        requestQueue.add(stringRequest);
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer, boolean b) {
        if(null== youTubePlayer) return;

        // Start buffering
        if (!b) {
            youTubePlayer.cueVideo("gfdgbs");
        }
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        Toast.makeText(this, "Failed to initialize.", Toast.LENGTH_LONG).show();
    }
}
