package com.example.musicsearchapp;

import java.util.List;

public class MusicData {

    String artist;
    String title;
    List<String> genre;
    String country;
    String coverImage;
    String masterURL;
    String yooutubeLink;
    String year;


    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getGenre() {
        return genre;
    }

    public void setGenre(List<String> genre) {
        this.genre = genre;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCoverImage() {
        return coverImage;
    }

    public void setCoverImage(String coverImage) {
        this.coverImage = coverImage;
    }

    public String getYooutubeLink() {
        return yooutubeLink;
    }

    public void setYooutubeLink(String yooutubeLink) {
        this.yooutubeLink = yooutubeLink;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getMasterURL() {
        return masterURL;
    }

    public void setMasterURL(String masterURL) {
        this.masterURL = masterURL;
    }
}
