package com.example.musicsearchapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import javax.xml.datatype.Duration;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    EditText editText;
    Spinner spinner;
    Button button;

    private String apiKey = "lTYysACPFwTSzodfndqhGzckNLRYPGMylFhuZIAL";

    MusicDataArrayAdapter musicDataArrayAdapter;
    ArrayList<MusicData> musicDataArrayList  = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        editText = findViewById(R.id.editText);
        spinner = findViewById(R.id.spinner);
        button = findViewById(R.id.button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchString = editText.getText().toString();
                String filterString = String.valueOf(spinner.getSelectedItem());

                musicDataArrayList = new ArrayList<>();
                httpRequest(searchString, filterString);

                musicDataArrayAdapter = new MusicDataArrayAdapter(MainActivity.this, musicDataArrayList);
                listView.setAdapter(musicDataArrayAdapter);

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                MusicData musicData = (MusicData) listView.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, SingleSongActivity.class);
                Log.d("DATA", musicData.getArtist());
                intent.putExtra("artist", musicData.getArtist());
                Log.d("DATA", musicData.getTitle());
                intent.putExtra("title", musicData.getTitle());
                // Find solution to List of genres

                int loop = 0;
                if(musicData.getGenre().size() > 0) {
                    for (int i = 0; i < musicData.getGenre().size(); i++) {
                        intent.putExtra("i", musicData.getGenre().get(i));
                        loop = i;
                    }
                }
                intent.putExtra("loop", loop);

                Log.d("DATA", musicData.getCountry());
                intent.putExtra("country", musicData.getCountry());
                Log.d("DATA", musicData.getCoverImage());
                intent.putExtra("coverImage", musicData.getCoverImage());
                Log.d("DATA", musicData.getMasterURL());
                intent.putExtra("masterURL", musicData.getMasterURL());
                Log.d("DATA", musicData.getYear());
                intent.putExtra("year", musicData.getYear());
                startActivity(intent);
            }
        });
    }

    public void httpRequest(String searchString, final String filterString) {
            String url = "https://api.discogs.com/database/search?" + filterString.toLowerCase() + "=" + searchString + "&token=" + apiKey;

            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Log.d("strrrrr",">>"+response);

                            try {
                                //getting the whole json object from the response
                                JSONObject obj = new JSONObject(response);

                                JSONArray results  = obj.getJSONArray("results");


                                if (results.length() == 0) {
                                    // Not working
                                    Toast.makeText(getApplicationContext(), "No results for the selected " + filterString, Toast.LENGTH_LONG);
                                }

                                for (int i = 0; i < results.length(); i++) {

                                    String masterURL;
                                    MusicData musicData = new MusicData();

                                    JSONObject songData = results.getJSONObject(i);
                                    if (songData.has("year")) {
                                        String year = songData.getString("year");
                                        musicData.setYear(year);
                                    } else {
                                        musicData.setYear("-");
                                    }

                                    String artistTitle = songData.getString("title");
                                    String[] aux = artistTitle.split(" - ");

                                    if (aux.length >= 2) {
                                        musicData.setArtist(aux[0]);
                                        musicData.setTitle(aux[1]);
                                    } else if (aux.length == 1) {
                                        musicData.setArtist(aux[0]);
                                        musicData.setTitle("No title");
                                    } else if (aux.length == 0) {
                                        musicData.setArtist("No artist");
                                        musicData.setTitle("No title");
                                    }

                                    if (songData.has("master_url")) {
                                        masterURL = songData.getString("master_url");
                                        musicData.setMasterURL(masterURL);
                                    } else {
                                        musicData.setMasterURL("-");
                                    }

                                    if(songData.has("country")) {
                                        String country = songData.getString("country");
                                        musicData.setCountry(country);
                                    } else {
                                        musicData.setCountry("-");
                                    }

                                    if(songData.has("cover_image")) {
                                        String coverImage = songData.getString("cover_image");
                                        musicData.setCoverImage(coverImage);
                                    } else {
                                        musicData.setCoverImage("-");
                                    }


                                    if(songData.has("genre")) {
                                        JSONArray genreArray = songData.getJSONArray("genre");

                                        List<String> genres = new ArrayList<>();
                                        for (int j=0; j<genreArray.length();j++) {
                                            String genreX = genreArray.getString(j);
                                            genres.add(genreX);
                                        }
                                        musicData.setGenre(genres);
                                    }

                                    // Code to add youtube link

                                    musicDataArrayList.add(musicData);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            //displaying the error in toast if occurrs
                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

            //creating a request queue
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            //adding the string request to request queue
        requestQueue.add(stringRequest);
    }
}
