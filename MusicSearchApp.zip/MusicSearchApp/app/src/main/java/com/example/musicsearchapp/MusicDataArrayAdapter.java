package com.example.musicsearchapp;

import android.content.Context;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.Priority;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestOptions;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class MusicDataArrayAdapter extends ArrayAdapter<MusicData> {
    private Context mContext;
    private List<MusicData> musicDataList;

    public MusicDataArrayAdapter(Context context, ArrayList<MusicData> list) {
        super(context, 0, list);
        this.mContext = context;
        this.musicDataList = list;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        View listItem = convertView;
        if(listItem == null)
            listItem = LayoutInflater.from(mContext).inflate(R.layout.list_item,parent,false);

        String imageURL = musicDataList.get(position).getCoverImage();

        ImageView imageView = listItem.findViewById(R.id.imageView);

        Glide
                .with(getContext())
                .load(imageURL)
                .centerCrop()
                .override(300,300)
                .error(R.drawable.no_photo)
                .into(imageView);

        /*Picasso
                .get()
                .load(imageURL)
                .fit()
                .centerCrop()
                .error(R.drawable.no_photo)
                .into((ImageView) listItem.findViewById(R.id.imageView));*/


        String artist = musicDataList.get(position).getArtist();
        String title = musicDataList.get(position).getTitle();
        TextView artistView = listItem.findViewById(R.id.artistView);
        TextView titleView = listItem.findViewById(R.id.titleView);

        artistView.setText(artist);
        titleView.setText(title);

        return listItem;
    }
}
