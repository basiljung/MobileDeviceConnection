package com.example.musicsearchapp;

import android.content.Context;
import android.widget.Toast;
import com.android.volley.*;
import com.android.volley.toolbox.*;
import org.json.*;
import java.util.ArrayList;

public class DeezerAPIReader {

    public ArrayList<MusicData> httpRequest(String searchString, final String filterString, final Context context) {
        String url = "https://api.deezer.com/search?q=" + filterString.toLowerCase() + ":'" + searchString.toLowerCase() + "'";
        final ArrayList<MusicData> musicDataArrayList = new ArrayList<>();

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject obj = new JSONObject(response);
                            JSONArray data  = obj.getJSONArray("data");

                            if (data.length() == 0) {
                                Toast.makeText(context, "No results for the selected " + filterString, Toast.LENGTH_LONG);
                            }

                            for (int i = 0; i < data.length(); i++) {
                                MusicData musicData = new MusicData();
                                JSONObject songData = data.getJSONObject(i);

                                if (songData.has("title")) {
                                    musicData.setSongTitle(songData.getString("title"));
                                } else {
                                    musicData.setSongTitle("-");
                                }

                                if (songData.has("link")) {
                                    musicData.setLinkToDeezer(songData.getString("link"));
                                } else {
                                    musicData.setLinkToDeezer("-");
                                }

                                if (songData.has("duration")) {
                                    musicData.setDuration(songData.getInt("duration"));
                                } else {
                                    musicData.setDuration(0);
                                }

                                if (songData.has("preview")) {
                                    musicData.setPreviewLink(songData.getString("preview"));
                                } else {
                                    musicData.setPreviewLink("-");
                                }

                                if (songData.has("artist")) {
                                    JSONObject artistObj = songData.getJSONObject("artist");
                                    if (artistObj.has("name")) {
                                        musicData.setArtistName(artistObj.getString("name"));
                                    } else {
                                        musicData.setArtistName("-");
                                    }

                                    if (artistObj.has("link")) {
                                        musicData.setArtistLink(artistObj.getString("link"));
                                    } else {
                                        musicData.setArtistLink("-");
                                    }

                                    if (artistObj.has("picture_big")) {
                                        musicData.setArtistImage(artistObj.getString("picture_big"));
                                    } else {
                                        musicData.setArtistImage("-");
                                    }
                                }

                                if (songData.has("album")) {
                                    JSONObject albumObj = songData.getJSONObject("album");
                                    if (albumObj.has("title")) {
                                        musicData.setAlbumName(albumObj.getString("title"));
                                    } else {
                                        musicData.setAlbumName("-");
                                    }

                                    if (albumObj.has("cover_big")) {
                                        musicData.setAlbumImage(albumObj.getString("cover_big"));
                                    } else {
                                        musicData.setAlbumImage("-");
                                    }
                                }
                                musicDataArrayList.add(musicData);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(context, error.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
        RequestQueue requestQueue = Volley.newRequestQueue(context);
        requestQueue.add(stringRequest);

        return musicDataArrayList;
    }
}
